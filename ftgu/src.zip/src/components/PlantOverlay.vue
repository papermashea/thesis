<template>
  <div class="plant-overlay">
    <div class="body" id="header"/>
<!--     <span v-for="p in plantDetails">this is for {{ plantDetails.id }}</span> -->
</div>
</template>

<script>
export default {
  name: "PlantOverlay",
  props: {
    plantDetails: { type: Object, required: true },
  },
  data() {
    return {
      // plantDetails: this.plantDetails,
    }
  },//close data
}//close export
</script>

<style>
</style>