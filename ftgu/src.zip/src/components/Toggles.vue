<template>
  <div class="tolerances">
  </div>
</template>

<script>

export default {
  name: "Toggles",

  components: {
  },
  data(){
    return {
    }
  }
};

</script>

<style>
</style>