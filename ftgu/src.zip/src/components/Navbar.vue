<template>
  <div class="nav">
    <nav class="navbar sticky-top">
      <a class="nav-links" href="#">From the ground up</a>
    </nav>
  </div>
</template>

<script>
  export default {
    name: 'Navbar',
  }

</script>

<style>
  .nav {
   text-align: left;
   padding: 1% 1% 1% 3%; 
  }
</style>